package com.driques.HU3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hu3Application {

	public static void main(String[] args) {
		SpringApplication.run(Hu3Application.class, args);
	}

}
