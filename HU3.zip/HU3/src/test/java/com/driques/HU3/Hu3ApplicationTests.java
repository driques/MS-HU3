package com.driques.HU3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hu3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
